/*
 * File: Caboose.java
 * ------------------
 * This class defines a caboose.  This implementation is
 * only a stub; filling in the details is left to the student
 * as an exercise.
 */

import acm.graphics.*;
import java.awt.*;

public class Caboose extends TrainCar {

/* Create the caboose */
	public Caboose() {
		super(Color.RED);
		// You fill in the rest //
	}

}

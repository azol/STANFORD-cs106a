/*
 * File: Engine.java
 * -----------------
 * This class defines the engine.  This implementation is
 * only a stub; filling in the details is left to the student
 * as an exercise.
 */

import acm.graphics.*;
import java.awt.*;

public class Engine extends TrainCar {

/* Creates the engine */
	public Engine() {
		super(Color.BLACK);
		// You fill in the rest //
	}

}

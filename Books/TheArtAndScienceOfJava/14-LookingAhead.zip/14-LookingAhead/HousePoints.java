/*
 * File: HousePoints.java
 * ----------------------
 * This program displays the house points for the Hogwarts houses
 * in both a bar graph and a pie chart view.  The purpose of the
 * program is to illustrate the model/view/controller pattern
 * described in Chapter 14.  This version, however, is unfinished;
 * completion of the program appears as exercise 7.
 */

import acm.program.*;

public class HousePoints extends GraphicsProgram {

	// You fill this in //

}
